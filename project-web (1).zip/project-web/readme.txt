PREREQUSITES: 
python3, pip and pipenv should be installed in your device.


1) Extract the project zip file and navigate to the extracted directory using a terminal. 
	Verify that the directory contains the Pipfile and Pipfile.lock.

Use the following commands in terminal or cmd.

2) pipenv shell  

3) pipenv install Django

4) pipenv install django-cors-headers

4) cd backend

5) ls if you are in mac, dir if you are in cmd

6) check if manage.py file in the following directory

7) python manage.py runserver
